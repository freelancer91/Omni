package omni.function;
public interface ShortComparator{
  int compare(short val1,short val2);
}
