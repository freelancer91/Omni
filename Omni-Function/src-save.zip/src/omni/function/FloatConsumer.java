package omni.function;
public interface FloatConsumer{
  void accept(float val);
}
