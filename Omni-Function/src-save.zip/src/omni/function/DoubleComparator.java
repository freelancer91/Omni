package omni.function;
public interface DoubleComparator{
  int compare(double val1,double val2);
}
