package omni.function;
public interface ShortPredicate{
  boolean test(short val);
}
