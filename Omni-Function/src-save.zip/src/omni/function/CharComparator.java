package omni.function;
public interface CharComparator{
  int compare(char val1,char val2);
}
