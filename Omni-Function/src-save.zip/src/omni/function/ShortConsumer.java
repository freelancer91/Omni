package omni.function;
public interface ShortConsumer{
  void accept(short val);
}
