package omni.function;
public interface FloatUnaryOperator{
  float applyAsFloat(float val);
}
