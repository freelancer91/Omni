package omni.function;
public interface CharConsumer{
  void accept(char val);
}
