package omni.function;
public interface BooleanPredicate{
  boolean test(boolean val);
}
