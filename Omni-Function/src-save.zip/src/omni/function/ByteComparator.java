package omni.function;
public interface ByteComparator{
  int compare(byte val1,byte val2);
}
