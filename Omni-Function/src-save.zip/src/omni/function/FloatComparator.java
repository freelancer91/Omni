package omni.function;
public interface FloatComparator{
  int compare(float val1,float val2);
}
