package omni.function;
public interface BooleanConsumer{
  void accept(boolean val);
}
