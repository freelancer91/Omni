package omni.function;
public interface BooleanComparator{
  int compare(boolean val1,boolean val2);
}
