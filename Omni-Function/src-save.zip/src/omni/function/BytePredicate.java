package omni.function;
public interface BytePredicate{
  boolean test(byte val);
}
