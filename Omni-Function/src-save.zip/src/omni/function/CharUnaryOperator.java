package omni.function;
public interface CharUnaryOperator{
  char applyAsChar(char val);
}
