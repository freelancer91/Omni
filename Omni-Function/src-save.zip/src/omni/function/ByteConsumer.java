package omni.function;
public interface ByteConsumer{
  void accept(byte val);
}
