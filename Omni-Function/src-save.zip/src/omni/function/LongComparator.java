package omni.function;
public interface LongComparator{
  int compare(long val1,long val2);
}
