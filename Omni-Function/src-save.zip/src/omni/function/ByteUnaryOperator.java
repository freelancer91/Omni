package omni.function;
public interface ByteUnaryOperator{
  byte applyAsByte(byte val);
}
