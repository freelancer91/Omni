package omni.function;
public interface CharPredicate{
  boolean test(char val);
}
