package omni.function;
public interface FloatPredicate{
  boolean test(float val);
}
