package omni.function;
public interface ShortUnaryOperator{
  short applyAsShort(short val);
}
