/**
 *
 */
/** @author lyonste */
module omni.function{
  exports omni.function;
}